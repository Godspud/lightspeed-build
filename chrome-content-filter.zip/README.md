# Chrome Content Filter Extension

A simple Chrome extension that blocks websites using a list of banned domains and keywords.

## 🚀 Features

- Blocks any URL containing banned domains or keywords.
- Works in the background via service worker.
- Easy to customize by editing `banned_domains.json` and `banned_keywords.json`.

## 🧪 How to Use

1. Open Chrome and go to `chrome://extensions/`
2. Turn on **Developer Mode**
3. Click **Load unpacked**
4. Select the `chrome-content-filter` folder
5. Done! Your filter is active.

## 🛡️ Caution

This is a basic educational filter and can be bypassed. For production, add a settings page, logs, and stronger rule matching.

## 📂 File Descriptions

- `manifest.json`: Chrome extension config
- `background.js`: Filtering logic
- `banned_domains.json`: List of blocked domains
- `banned_keywords.json`: List of blocked keywords